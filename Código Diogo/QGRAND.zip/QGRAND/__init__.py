# import statistics
# import error
# import pauli
# import hamming
# import encoding
# import plotting